# 2id70Test

This is a sample git repository for completing milestone 1. Have a look at the files.
