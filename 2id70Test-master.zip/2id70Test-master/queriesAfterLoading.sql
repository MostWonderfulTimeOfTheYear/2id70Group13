-- here you will write the three queries requested in Question 1. Each query should be in a single line, i.e., do not break long queries to more lines.
SELECT 'Replace this line with query 1';
SELECT 'Replace this line with query 2';
SELECT 'Replace this line with query 3';
